// Developed by Gavin George

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerState.h"
#include "GG_RTS_PlayerState.generated.h"

/**
 * 
 */
UCLASS()
class RTS_BASEBUILDER_API AGG_RTS_PlayerState : public APlayerState
{
	GENERATED_BODY()

};
