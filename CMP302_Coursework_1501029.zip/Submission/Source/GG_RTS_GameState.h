// Developed by Gavin George

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameStateBase.h"
#include "GG_RTS_GameState.generated.h"

/**
 * 
 */
UCLASS()
class RTS_BASEBUILDER_API AGG_RTS_GameState : public AGameStateBase
{
	GENERATED_BODY()
	
};
