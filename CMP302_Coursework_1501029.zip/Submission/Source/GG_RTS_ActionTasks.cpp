// Developed by Gavin George


#include "GG_RTS_ActionTasks.h"

GG_RTS_ActionTasks::GG_RTS_ActionTasks()
{

}

GG_RTS_ActionTasks::~GG_RTS_ActionTasks()
{
}
